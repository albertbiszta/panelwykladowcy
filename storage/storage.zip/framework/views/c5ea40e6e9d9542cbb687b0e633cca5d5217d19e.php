<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH E:\LARAVEL ALL\panelwykladowcy\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>