<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">

				<div class="card-header">
					Oceny z przedmiotu
					<b> 
						<a href="<?php echo e(url('subjects', $subject->id)); ?>" style="color: black"> 
							<?php echo e($subject->name); ?>


						</a> 
					</b>
					Grupa: 
					<b> 
						<a href="<?php echo e(url('groups', $group->id)); ?>" style="color: black"> 
							<?php echo e($group->name); ?>


						</a>
					</b>
				</div>

				


				<div class="card-body justify-content-center">
					<div>
						<div class="alert alert-success alert-block"  id="success-info" style="display: none">
							<button type="button" class="close" data-dismiss="alert" >×</button> 
							<strong>
								<p id="info">
								</p>
							</strong>
						</div>

					</div>

					<b>   
						


							
							<a href="<?php echo e(route('lessons.group',[$subject->id, $group->id])); ?>" style="color: black"> 
								<i class="far fa-arrow-alt-circle-left  fa-lg"></i> Wróć do zajęć   </a>
								<div class="float-right" > 
									<a class="btn btn-outline-secondary button-1 btn-sm" role="button" id="save-grades">
										Zatwierdź oceny
									</a>



								</div>


							</b>

							<br> <br>


							<table class="table table-bordered table-sm table-responsive-sm">
								<thead>
									<tr>
										<th scope="col">Nazwisko</th>
										<th scope="col">Imię</th>
										<th scope="col">Numer indeksu</th>
										<th scope="col">Oceny <div class="float-right">Dodaj  </div></th>

										<th scope="col">Średnia</th>



									</th>

								</tr>
							</thead>
							<tbody>
								

								<?php $__currentLoopData = $group->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

								<tr>
									<td> <?php echo e($student->last_name); ?> </td>
									<td> <?php echo e($student->first_name); ?> </td>
									<td> <?php echo e($student->index_number); ?> </td>

									
									<td>
										<div class="grades-tab"> 

										<?php $__currentLoopData = $student->grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
										<a id="grade-square"  data-toggle="modal" data-target="#editGrade" data-id="<?php echo e($grade->id); ?>" 
											data-value="<?php echo e($grade->value); ?>">
											<?php echo e(substr($grade->value,0,3)); ?> </a> 
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

											
											<input class="form-control add-grade-input" name="add-grade-input" id="add-grade-input" data-id="<?php echo e($student->id); ?>">

											
											</div>
										</td>

										<td>
											<b>  <?php echo e(substr(App\Student::averageGrade($student->id,$subject->id), 0, 4)); ?>  </b>
											
										</td>






									</tr>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</tbody>
							</table>

							

						</div>






						
						<div class="modal fade" id="editGrade" tabindex="-1" role="dialog" data-dismiss="modal" aria-label="Close">
							<div class="modal-dialog" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<h4 class="modal-title">Edytuj / Usuń ocenę </h4>
										
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>

									</div>


									<div class="modal-body float-center">

										<div class="alert alert-danger alert-block"  id="validation-edit" style="display:none">

										</div>
										
										

										<button type="submit" data-toggle="modal" data-target="delete-grade" id="delete-grade" 
										class="btn btn-light float-right">
										<i class="far fa-trash-alt fa-lg"></i> <b>Usuń ocenę </b>
									</button>






									<div class="form-group">
										<div  class="col-md-4 control-label">

										</div>
										<div class="col-md-8">
											<?php echo Form::text('value',null,['class'=>'form-control', 'placeholder'=>'Ocena (np. 4.0)', 'id'=>'editGradeValue']); ?>

										</div>
									</div>

									<div class="form-group">
										<div class="col-md-6 col-md-offset-4">
											<?php echo Form::submit('Zapisz zmiany',['class'=>'btn btn-outline-secondary float-right', 'id'=>'submitGradeUpdate']); ?>

										</div>
									</div>


									

								</div>

							</div><!-- /.modal-content -->
						</div><!-- /.modal-dialog -->
					</div><!-- /.modal -->


					<input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="subjectId" id="subjectId" value="<?php echo e($subject->id); ?>">
					<input type="hidden" name="groupId" id="groupId" value="<?php echo e($group->id); ?>">



					<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL ALL\panelwykladowcy\resources\views/grades/group.blade.php ENDPATH**/ ?>