<?php echo e($slot); ?>

<?php /**PATH E:\LARAVEL ALL\panelwykladowcy\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>