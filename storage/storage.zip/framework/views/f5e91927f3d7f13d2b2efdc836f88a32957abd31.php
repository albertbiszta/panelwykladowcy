<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">

				<div class="card-header">
					<b> 
						<a href="<?php echo e(url('subjects', $subject->id)); ?>" style="color: black"> 
							<?php echo e($subject->name); ?>


						</a> 
					</b>
					Grupa: 
					<b> 
						<a href="<?php echo e(url('groups', $group->id)); ?>" style="color: black"> 
							<?php echo e($group->name); ?>


						</a>
					</b>

					   <a href="<?php echo e(action('GradeController@groupGrades', [$subject->id, $group->id])); ?>" class="float-right" style="color: black"> 
                      <i class="far fa-file-alt fa-lg" style="color: black"></i>
                      Wyświetl oceny

                  </a>
					</div>
				



				<div class="card-body">
					<?php if(Session::has('flash_message_error')): ?>
					<div class="alert alert-error alert-block">
						<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong><?php echo session('flash_message_error'); ?></strong>
					</div>
					<?php endif; ?>   
					<?php if(Session::has('flash_message_success')): ?>
					<div class="alert alert-success alert-block">
						<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong><?php echo session('flash_message_success'); ?></strong>
					</div>
					<?php endif; ?>
 

					<a class="btn btn-outline-secondary button-1 float-right" id="open-addLesson-modal" href="#" role="button" data-toggle="modal" 
					data-target="#addLesson" aria-haspopup="true" aria-expanded="false">
					Dodaj zajęcia
				</a>


			</div>



			<div class="card-body">

				<?php if((count($subject->lessons) > 0) && (count($group->lessons) > 0)): ?>
				<table class="table table-bordered table-sm table-responsive-sm">
					<thead>
						<tr >
							<th scope="col">Data</th>
							<th scope="col">Temat zajęć</th>
							<th scope="col">Status</th>
							<th scope="col">Zmień status</th>
							<th scope="col">Obecność</th>




						</th>

					</tr>
				</thead>
				<tbody id="lessons-tbody">


					<?php $__currentLoopData = $group->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupLesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php $__currentLoopData = $subject->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subjectLesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($groupLesson->id == $subjectLesson->id): ?>





					<tr>
						<td> 
							<div class="lessons-tab"> 
								<?php echo e($groupLesson->date->format('d-m-Y')); ?>

							</div>
							 
						</td>
						<td> 
							<div class="lessons-tab"> 
							<?php echo e($groupLesson->topic); ?> 
							</div>
						</td>


						<?php if($groupLesson->performed == 1): ?>
						
						<td> 	
<div class="lessons-tab"> 
							Odbyły się
							</div>
						</td>

						<td> 	



						</td>

						<?php else: ?>
						<td> 	
							<div class="lessons-tab"> 
							Nie odbyły się
							</div>
						</td>

						<td> 	
							<?php echo Form::model($groupLesson, ['method'=>'PATCH', 
							'action'=>['LessonController@editStatus', $groupLesson->id]]); ?>

							<?php echo Form::hidden('performed', 1); ?>





							<?php echo e(Form::button('<i class="fas fa-plus-circle fa-lg"></i>', [ 'type'=>'submit' , 'class' => 'btn btn-light btn-sm'])); ?>




							<?php echo Form::close(); ?>   

						</td>


						<?php endif; ?>




						<td>
							<?php if($groupLesson->performed == 1): ?>

							<a href="<?php echo e(action('AttendanceController@lessonAttendance', $groupLesson->id)); ?>" style="color: black"> 
								<i class="fas fa-chalkboard" style="color: black"></i>

							</a>
							<?php endif; ?>	
						</td>









					</tr>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</tbody>
				<tfoot class="table-borderless">
					<tr>
						<th></th>
						<th></th>
						<th></th>
						<th>   Liczba odbytych zajęć: </th>
						<th> <?php echo e(App\Lesson::where('subject_id', $subject->id)->where('group_id', $group->id)->where('performed', 1)->count()); ?>	</th>
					</tr>
				</tfoot>
			</table>

			<?php else: ?>
			<p>[ Nie dodałeś jeszcze zajęć dla tego przedmiotu i grupy ]</p>

			<?php endif; ?>

		</div>


		<div class="card-body">



			

			<h6><b>Frekwencja studentów</b></h6>




			<table class="table table-bordered table-sm table-responsive-sm">
				<thead>
					<tr>
						<th scope="col">Nazwisko i Imię</th>
						<th scope="col">Obecności</th>
						<th scope="col">Nieobecności</th>
						<th scope="col">Nb. usprawiedliwione</th>



					</th>

				</tr>
			</thead>
			<tbody id="students-tbody">


				<?php $__currentLoopData = $group->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<?php
				$ob = 0;
				$nb = 0;
				$uspr = 0;
				?>

				<tr>
					<td> <?php echo e($student->lastName); ?> <?php echo e($student->firstName); ?>  </td>

					<?php
					$studentAttendances = App\Student::studentAttendances($student->id,$subject->id);

					?>

					<td>

						
						<?php echo e($studentAttendances['ob']); ?>


					</td>

					<td>
						<?php echo e($studentAttendances['nb']); ?>

					</td>

					<td>
						<?php echo e($studentAttendances['uspr']); ?>

					</td>





				</tr>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</tbody>
		</table>





	</div>
</div>
</div>
</div>
</div>
</div>
 

<input type="hidden" name="subjectId" id="subjectId" value="<?php echo e($subject->id); ?>">
<input type="hidden" name="groupId" id="groupId" value="<?php echo e($group->id); ?>">

<input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">






<div class="modal fade" id="addLesson" tabindex="-1" role="dialog" data-dismiss="modal">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Dodaj nowe zajęcia</h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>

			</div>
			<div class="modal-body">

				<div class="alert alert-danger alert-block"  id="validation-info" style="display:none">

				</div>

				


				<?php echo Form::open(['action'=> ['LessonController@add',
					$subject->id, $group->id],
					'method'=>'POST', 'class' =>'form-horizontal', 'id'=>'form-addLesson',]); ?>


					<div class="form-group">
						<div  class="col-md-4 control-label">
							<?php echo Form::label('date', 'Data zajęć:'); ?>

						</div>
						<div class="col-md-8">

							<?php echo Form::date('date', date('D-m-y'),['class' => 'form-control', 'id'=>'lessonDate']); ?>

						</div>
					</div>





					<div class="form-group">
						<div  class="col-md-4 control-label">
							<?php echo Form::label('topic','Temat:'); ?>

						</div>
						<div class="col-md-8">
							<?php echo Form::textarea('topic',null,['class'=>'form-control','rows' => 2, 'cols' => 54, 'style' => 'resize:none', 'id'=>'topic']); ?>

						</div>
					</div>

					<div class="form-group">
						<div  class="col-md-8 control-label">

						</div>
						<div class="col-md-8">
							<?php echo Form::label('performed','Odbył się:'); ?>


							<?php echo Form::checkbox('performed', 1 );; ?>


						</div>
					</div>

					<div class="modal-footer">

						<div class="form-group">



							<div class="col-md-6 col-md-offset-4">
								<?php echo Form::submit('Dodaj zajęcia',['class'=>'btn btn-outline-secondary float-right', 'id'=>'lesson-submit']); ?>


							</div>
						</div>

						<?php echo Form::close(); ?>   
					</div>
				</div>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aba\Desktop\LARAVEL ALL\panelwykladowcy\resources\views/lessons/group.blade.php ENDPATH**/ ?>