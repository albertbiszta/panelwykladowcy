<?php echo e($slot); ?>

<?php /**PATH C:\Users\aba\Desktop\LARAVEL ALL\panelwykladowcy\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>