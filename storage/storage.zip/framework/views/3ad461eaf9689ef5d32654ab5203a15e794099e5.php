<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">

				<div class="card-header">
					Lista obecności: <b>  <?php echo e($lesson->date->format('d-m-Y')); ?>  </b>       
					Przedmiot:  
					<b> 
						<a href="<?php echo e(url('subjects', $subject->id)); ?>" style="color: black"> 
							<?php echo e($subject->name); ?>


						</a> 
					</b>
					Grupa: 
					<b> 
						<a href="<?php echo e(url('groups', $group->id)); ?>" style="color: black"> 
							<?php echo e($group->name); ?>


						</a>
					</b>
				</div>

				

				<div class="card-body">

					
					<a href="<?php echo e(route('lessons.group',[$subject->id, $group->id])); ?>" style="color: black"> 
						<i class="far fa-arrow-alt-circle-left  fa-lg"></i> Wróć do zajęć   </a>
<div id="main">
						<?php if(count($lesson->attendances) > 0): ?>

						<button class="btn btn-outline-secondary float-right" id="update-attendance"> Zatwierdź zmiany w obecności</button>
						<br> <br>

						<table class="table table-bordered table-sm table-responsive-sm">
							<thead>
								<tr>
									<th scope="col">Nazwisko</th>
									<th scope="col">Imię</th>
									<th scope="col">Numer indeksu</th>
									<th scope="col">Status obecności</th>


								</tr>
							</thead>
							<tbody id="attendances-tbody">


								<?php $__currentLoopData = $lesson->attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


								<?php $__currentLoopData = $group->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


								<?php if($attendance->student_id == $student->id): ?>

								<tr>


									<td> <?php echo e($student->last_name); ?> </td>
									<td> <?php echo e($student->first_name); ?> </td>
									<td> <?php echo e($student->index_number); ?> </td>


									<td> 


										<select class="form-control" name="status" id="status" data-id="<?php echo e($attendance->id); ?>">

											<?php if($attendance->status == 'Obecny'): ?>
											<option value="Obecny" disable="true" selected="true"> Obecny </option>
											<option value="Nieobecny"> Nieobecny </option>
											<option value="Nieobecność usprawiedliwiona"> Nieobecność usprawiedliwiona </option>


											<?php elseif($attendance->status == 'Nieobecny'): ?>

											<option value="Nieobecny" disable="true" selected="true"> Nieobecny </option>
											<option value="Obecny"> Obecny </option>
											<option value="Nieobecność usprawiedliwiona"> Nieobecność usprawiedliwiona </option>

											<?php else: ?>
											<option value="Nieobecność usprawiedliwiona" disable="true" selected="true"> Nieobecność usprawiedliwiona </option>
											<option value="Obecny"> Obecny </option>
											<option value="Nieobecny"> Nieobecny </option>

											<?php endif; ?>
											


										</select>


									
								</td>




							</tr>

							<?php endif; ?>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</tbody>
					</table>




					<?php else: ?>
				

					<button class="btn btn-outline-secondary float-right" id="submit-attendance"> Zatwierdź obecność </button>
					<br> <br>



					<table class="table table-bordered table-sm">
						<thead>
							<tr>
								<th scope="col">Nazwisko</th>
								<th scope="col">Imię</th>
								<th scope="col">Numer indeksu</th>
								<th scope="col">Status obecności</th>







							</tr>
						</thead>
						<tbody>


							<?php $__currentLoopData = $group->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


							<tr>


								<td> <?php echo e($student->last_name); ?> </td>
								<td> <?php echo e($student->first_name); ?> </td>
								<td> <?php echo e($student->index_number); ?> </td>


								<td> 


									<div > 
										<select class="form-control" name="status" id="status" data-id="<?php echo e($student->id); ?>">
											<option value="Obecny" disable="true" selected="true"> Obecny </option>


											<option value="Nieobecny"> Nieobecny </option>
											<option value="Nieobecność usprawiedliwiona"> Nieobecność usprawiedliwiona </option>


										</select>
									</div>

								</td>




							</tr>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</tbody>
					</table>

					<?php endif; ?>





				</div>	




			</div>


			<input type="hidden" name="lessonId" id="lessonId" value="<?php echo e($lesson->id); ?>">

			<input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">






		</div>
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL ALL\panelwykladowcy\resources\views/attendances/lesson.blade.php ENDPATH**/ ?>