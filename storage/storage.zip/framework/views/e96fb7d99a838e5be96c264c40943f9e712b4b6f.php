<div>
	<?php $__env->startSection('content'); ?>
	
	<div class="container">
		<div class="row justify-content-center">
			<div class="card"  style="width: 65rem;" >


				<div class="card-header">
					<h5 >
						<b> Udostępnij materiały dla studentów</b>   

					</h5>  	
				</div>


				<div class="card-body">

					<?php if(Session::has('flash_message_error')): ?>
					<div class="alert alert-error alert-block">
						<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong><?php echo session('flash_message_error'); ?></strong>
					</div>
					<?php endif; ?>   
					<?php if(Session::has('flash_message_success')): ?>
					<div class="alert alert-success alert-block">
						<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong><?php echo session('flash_message_success'); ?></strong>
					</div>
					<?php endif; ?>

					<div>
						<div class="alert alert-success alert-block"  id="success-info" style="display: none">
							<button type="button" class="close" data-dismiss="alert" >×</button> 
							<strong>
								<p id="info">
								</p>
							</strong>
						</div>

					</div>

					


				</div>
				<div class="card-body justify-content-center">
					<?php echo Form::open(['route' => 'syllabuses.store']); ?>



<div class="form-group ">
   <div  class="col-md-4 control-label">
       <?php echo Form::label('subject','Przedmiot: '); ?>

   </div>
   <div  class="col-md-6">

       <select class="form-control" name="subject" id="exampleFormControlSelect2">
           <option value="" disable="true" selected="true"> Wybierz przedmiot </option>
           <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


           <option value="<?php echo e($key); ?>"><?php echo e($value); ?> </option>


           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </select>


   </div>
</div>








<div class="form-group">
   <div  class="col-md-4 control-label">
       <?php echo Form::label('language','Język: '); ?>

   </div>
   <div class="col-md-6">

    <select class="form-control" name="language" id="exampleFormControlSelect2">
       <option value="" disable="true" selected="true"> Wybierz język </option>

       <option value="Polski"> Polski </option>
       <option value="Angielski"> Angielski </option>
       <option value="Niemiecki"> Niemiecki </option>



   </select>
</div>
</div>

<div class="form-group">
<div  class="col-md-4 control-label">
   <?php echo Form::label('description','Opis:'); ?>

</div>
<div class="col-md-6">
   <?php echo Form::textarea('description',null,['class'=>'form-control','rows' => 6, 'cols' => 44]); ?>

</div>
</div>

<div class="form-group">
<div  class="col-md-4 control-label">
   <?php echo Form::label('literature','Literatura:'); ?>

</div>
<div class="col-md-6">
   <?php echo Form::textarea('literature',null,['class'=>'form-control','rows' => 3, 'cols' => 54]); ?>

</div>
</div>



<div class="form-group">
<div class="col-md-6 col-md-offset-4">
   <?php echo Form::submit('Dodaj sylabus',['class'=>'btn btn-outline-secondary float-right']); ?>

  </div>
</div>



                <?php echo Form::close(); ?>


				</div>
				




			</div>
		</div>
	</div>


	<input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">








</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aba\Desktop\LARAVEL ALL\panelwykladowcy\resources\views/materials/create.blade.php ENDPATH**/ ?>