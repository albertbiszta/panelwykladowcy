<?php $__env->startSection('content'); ?>



<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card">
        <div class="card-header">
          <b>  
            <?php echo e($user->lastName); ?>  <?php echo e($user->firstName); ?> 


          </b>

        </div>

        <div class="card-body">
          <div>
            <div class="alert alert-success alert-block"  id="success-info" style="display: none">
              <button type="button" class="close" data-dismiss="alert" >×</button> 
              <strong>
                <p id="info">
                </p>
              </strong>
            </div>

          </div>

          <?php if(count($subjects) > 0): ?>

          <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(count($subject->materials) > 0): ?>


          <div class="card">
            <div class="card-header">
              <b> <?php echo e($subject->name); ?> </b>
            </div>
            <div class="card-body">
              <ul class="list-group list-group-flush">



                <?php $__currentLoopData = $subject->materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>





                <li class="list-group-item mh-25"><?php echo e($material->name); ?>   
                  <a  href="<?php echo e(route('materials.download', [$material->fileName])); ?>" class="float-right mh-25" > 
                    <button class="btn btn-outline-secondary button-1 mh-25" >Pobierz</button>

                  </a>  
                
                </li>









                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </ul>
            </div>
          </div>
          <br> 




          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php endif; ?>










        </div>
      </div>
    </div>
    <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">

    <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aba\Desktop\LARAVEL ALL\panelwykladowcy\resources\views/profiles/public.blade.php ENDPATH**/ ?>