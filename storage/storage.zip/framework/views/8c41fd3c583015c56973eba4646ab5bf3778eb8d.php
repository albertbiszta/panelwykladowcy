<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">
					<i href="/syllabuses/create" class="fas fa-plus-circle fa-lg"></i>
					<a href="/syllabuses/create">Dodaj sylabus	</a>
				</div>

				<div class="card-body">



				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aba\Desktop\LARAVEL ALL\panelwykladowcy\resources\views/syllabuses/index.blade.php ENDPATH**/ ?>