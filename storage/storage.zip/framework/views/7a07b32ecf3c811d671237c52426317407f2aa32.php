[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\Users\aba\Desktop\LARAVEL ALL\panelwykladowcy\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>