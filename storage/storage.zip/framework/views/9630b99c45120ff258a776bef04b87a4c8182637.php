<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">
	
					<a href="/studentse">  	</a>

					<h5>Wyniki wyszukiwania</h5>
				</div>

				<div class="card-body">

				 <div class="search-container">
				 	<table class="table table-borderless">
						<thead>
							<tr>
								<th scope="col">Imię</th>
								<th scope="col">Nazwisko</th>
								<th scope="col">Grupa</th>
								<th scope="col">Numer indeksu</th>
						
								


								</th>
								
							</tr>
						</thead>
						<tbody>


							<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<tr>
								<td><?php echo e($student->firstname); ?> </td>

								<td> <?php echo e($student->lastname); ?> </td>
								<td> <?php echo e($student->indexNumber); ?></td>
										<td> <?php echo e($student->group->name); ?></td>
						
								

								


							</tr>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</tbody>
					</table>
				 	
			
				 </div>


				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aba\Desktop\LARAVEL ALL\panelwykladowcy\resources\views/students/search-results.blade.php ENDPATH**/ ?>